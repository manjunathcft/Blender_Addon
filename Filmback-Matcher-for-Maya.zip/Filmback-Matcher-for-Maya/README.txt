To run this script a shelf button of the following commands should be made. This will work in both Python 2 and Python 3 environments.

import sys
import importlib
pV = sys.version_info[0]
import camFXDB
if pV>2:
    importlib.reload(camFXDB)
else:
    reload(camFXDB)
camFXDB.initialize()