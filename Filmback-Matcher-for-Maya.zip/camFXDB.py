# import camFXDB;import importlib;importlib.reload(camFXDB);camFXDB.initialize();
# Flimback Matcher. Creates camera like you want.

import sys
import re
import maya.cmds as cmds

# Define global variable at module level
vfx_cam_db_ui_stuff = {}

encoding = 'utf-8'
python_version = sys.version_info[0]
excluded_keywords = [
    'feed', 'articles', 'film-back-calculator', 'about-2', 'contact', 'donate',
    'lens-image-circle-and-sensor-imaging-area', 'image-circle-database', 'phfx',
    'camera-apertures-and-image-formats', 'dslr-sensor-formats',
    'dslr-sensor-dimensions-table', 'film-scanning-dimensions', 'film-back-calculator'
]


def initialize():
    url = 'https://www.vfxcamdb.com'
    if python_version < 3:
        import urllib2
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        html = urllib2.urlopen(req).read()
    else:
        import urllib.request
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        html1 = urllib.request.urlopen(req).read()
        html = html1.decode(encoding)
    
    links = re.findall('"((http|ftp)s?://.*?)"', html)
    global vfx_cam_db_ui_stuff
    vfx_cam_db_ui_stuff = {}
    build_ui(links)


def build_ui(links):
    menu_items = []
    if cmds.window('vfxcamdbUI', ex=True):
        cmds.deleteUI('vfxcamdbUI', window=True)
    cmds.window('vfxcamdbUI', sizeable=True, title='Create_Camera v.1.0')
    cmds.columnLayout('vfxcamdbUIMC', adj=True, cat=["both", 18])
    cmds.separator(h=20, style="none")
    opt_menu = cmds.optionMenu(label="Camera")
    cmds.optionMenu(opt_menu, e=1, cc='camFXDB.get_info("' + opt_menu + '")')
    
    for link in links:
        if link[0].startswith("http"):
            temp_item = link[0].replace('http://vfxcamdb.com/', '')
            temp_item = temp_item.replace('https://vfxcamdb.com/', '')
            temp_item = temp_item.replace('camera/', '')
            temp_item = temp_item.replace('format/', '')
            
            spl = link[0].split("/")
            if len(spl) == 5:
                if "?" not in temp_item and temp_item != '' and not temp_item.endswith('.js') and \
                        not temp_item.endswith('.php') and not temp_item.endswith('.png') and \
                        not temp_item.startswith('category') and not temp_item.startswith('http') and \
                        not temp_item.startswith('wp-'):
                    
                    is_excluded = False
                    for keyword in excluded_keywords:
                        if temp_item == keyword + "/":
                            is_excluded = True
                            break
                    if is_excluded:
                        continue
                    menu_items.append(temp_item)
    
    menu_sort = sorted(menu_items)
    for item in menu_sort:
        cmds.menuItem(item, p=opt_menu)
    cmds.showWindow('vfxcamdbUI')
    get_info(opt_menu)


def get_info(opt_menu):
    temp_cam = cmds.optionMenu(opt_menu, q=1, v=1)
    global vfx_cam_db_ui_stuff
    vfx_cam_db_ui_stuff = {}
    url_temp = 'https://www.vfxcamdb.com/' + temp_cam

    if python_version < 3:
        import urllib2
        req = urllib2.Request(url_temp, headers={'User-Agent': 'Mozilla/5.0'})
        html = urllib2.urlopen(req).read()
    else:
        import urllib.request
        req = urllib.request.Request(url_temp, headers={'User-Agent': 'Mozilla/5.0'})
        html1 = urllib.request.urlopen(req).read()
        html = html1.decode(encoding)
        
    cmds.columnLayout('vfxcamdbUIMC', e=True, h=100)
    if cmds.columnLayout('vfxcamdbUIMCMini', q=1, ex=1):
        cmds.deleteUI('vfxcamdbUIMCMini', layout=True)
    cmds.setParent('vfxcamdbUIMC')
    cmds.columnLayout('vfxcamdbUIMCMini', adj=True)
    cmds.separator(h=30, style="none")
    
    counter = 0
    split_html = html.splitlines()
    for line in split_html:
        # Sensor Type
        if "Sensor Type" in line and ("strong" in line or "b>" in line):
            if counter + 1 < len(split_html):
                sensor_type = dig_replace(split_html[counter + 1].replace('</p>', ''))
                cmds.rowLayout(nc=2)
                cmds.text("Sensor Type:")
                vfx_cam_db_ui_stuff["sensorType"] = cmds.text("  " + sensor_type + "  ", bgc=[.18, .18, .18])
                cmds.setParent('..')
            
        # Shutter
        if "Shutter" in line and ("strong" in line or "b>" in line):
            if counter + 1 < len(split_html):
                cmds.separator(h=10, style="none")
                shutter = dig_replace(split_html[counter + 1].replace('</p>', ''))
                cmds.rowLayout(nc=2)
                cmds.text("Shutter:")
                vfx_cam_db_ui_stuff["shutter"] = cmds.text("  " + shutter + "  ", bgc=[.18, .18, .18])
                cmds.setParent('..')
            
        # Image Resolution
        if "Image Resolution" in line and ("strong" in line or "b>" in line):
            cmds.separator(h=10, style="none")
            counter2 = 1
            t = "no"
            cmds.text("Image Resolutions:", al="left")
            cmds.separator(h=4, style="none")
            temp_scroll = cmds.textScrollList(nr=5)
            vfx_cam_db_ui_stuff["imageResolutionScroll"] = temp_scroll
            while t == "no" and (counter + counter2) < len(split_html):
                line_check = split_html[counter + counter2]
                dig1 = dig_replace(line_check)
                if line_check.startswith("<p><strong") or line_check.startswith("<p><b"):
                    t = "yes"
                else:
                    cmds.textScrollList(temp_scroll, e=1, append=((dig1.replace('<br />', '')).replace('<p>', '')).replace('</p>', ''))
                counter2 = counter2 + 1
            ht = cmds.textScrollList(temp_scroll, q=1, ni=True)
            cmds.textScrollList(temp_scroll, e=1, sii=1)
            if ht > 10:
                ht = 10
            cmds.textScrollList(temp_scroll, e=1, nr=ht)
            
        # Sensor Imaging Area
        if "Sensor Imaging Area" in line and ("strong" in line or "b>" in line):
            cmds.separator(h=10, style="none")
            counter2 = 1
            t = "no"
            cmds.text("Sensor Imaging Area:", al="left")
            cmds.separator(h=4, style="none")
            temp_scroll2 = cmds.textScrollList(nr=5)
            vfx_cam_db_ui_stuff["sensorAreaScroll"] = temp_scroll2
            while t == "no" and (counter + counter2) < len(split_html):
                line_check = split_html[counter + counter2]
                dig1 = dig_replace(line_check)
                if line_check.startswith("<span"):
                    counter2 = counter2 + 1
                    continue
                if line_check.startswith("<p><strong>") or line_check.startswith("<p><b"):
                    t = "yes"
                else:
                    cmds.textScrollList(temp_scroll2, e=1, append=((dig1.replace('<br />', '')).replace('<p>', '')).replace('</p>', ''))
                counter2 = counter2 + 1
            ht = cmds.textScrollList(temp_scroll2, q=1, ni=True)
            cmds.textScrollList(temp_scroll2, e=1, sii=1)
            if ht > 10:
                ht = 10
            cmds.textScrollList(temp_scroll2, e=1, nr=ht)
            
        # Sensor Dimensions
        if "Sensor Dimensions" in line and ("strong" in line or "b>" in line):
            cmds.separator(h=10, style="none")
            counter2 = 1
            t = "no"
            cmds.text("Sensor Dimensions:", al="left")
            cmds.separator(h=4, style="none")
            temp_scroll3 = cmds.textScrollList(nr=1)
            vfx_cam_db_ui_stuff["sensorDimensionsScroll"] = temp_scroll3
            suff = ""
            while t == "no" and (counter + counter2) < len(split_html):
                line_check = split_html[counter + counter2]
                dig1 = dig_replace(line_check)
                if dig1.startswith("<span"):
                    counter2 = counter2 + 1
                    continue
                if dig1.startswith("<a href"):
                    counter2 = counter2 + 1
                    continue
                if dig1.startswith("<p><em"):
                    suff = "   *** " + dig1.replace("<p>", "").replace('<em>', '').replace("</em>", "").replace("<br />", "") + " ***"
                    counter2 = counter2 + 1
                    continue
                if line_check.startswith("<p><strong>") or line_check.startswith("<p><b"):
                    t = "yes"
                else:
                    cmds.textScrollList(temp_scroll3, e=1, append=((dig1.replace('<br />', '')).replace('<p>', '')).replace('</p>', '') + suff)
                counter2 = counter2 + 1
            ht = cmds.textScrollList(temp_scroll3, q=1, ni=True)
            cmds.textScrollList(temp_scroll3, e=1, sii=1)
            if ht > 10:
                ht = 10
            cmds.textScrollList(temp_scroll3, e=1, nr=ht)
            if ht == 1:
                cmds.textScrollList(temp_scroll3, e=1, en=False)
                
        # Output Type
        if "Output Type" in line and ("strong" in line or "b>" in line or '>Output Type:<' in line):
            cmds.separator(h=10, style="none")
            cmds.text("Output Types:", al="left")
            cmds.separator(h=4, style="none")
            temp_scroll3 = cmds.textScrollList(nr=5)
            vfx_cam_db_ui_stuff["outputTypeScroll"] = temp_scroll3
            counter2 = 1
            t = "no"
            while t == "no" and (counter + counter2) < len(split_html):
                line_check = split_html[counter + counter2]
                dig1 = dig_replace(line_check)
                if '<!-- .entry-content -->' in dig1:
                    t = "yes"
                    continue
                elif dig1.endswith("</p>"):
                    cmds.textScrollList(temp_scroll3, e=1, append=dig1.replace('</p>', ''))
                    t = "yes"
                elif line_check.startswith("<p>"):
                    cmds.textScrollList(temp_scroll3, e=1, append=dig1.replace('<p>', '').replace('<br />', ''))
                else:
                    cmds.textScrollList(temp_scroll3, e=1, append=dig1.replace('<br />', '').replace('<p>', ''))
                counter2 = counter2 + 1
            ht = cmds.textScrollList(temp_scroll3, q=1, ni=True)
            if ht > 10:
                ht = 10
            cmds.textScrollList(temp_scroll3, e=1, nr=ht)
            cmds.textScrollList(temp_scroll3, e=1, sc='import maya.cmds as cmds;cmds.textScrollList("' + temp_scroll3 + '",e=1,da=True)')
        counter = counter + 1
        
    cmds.separator(h=20, style="none")
    vfx_cam_db_ui_stuff["camName"] = cmds.textFieldGrp(label="Camera Name:", cw=[(1, 75), (2, 200)], tx='cam_main')
    cmds.columnLayout(cat=["left", 40], adj=True)
    vfx_cam_db_ui_stuff["check"] = cmds.checkBox(l=" Use image resolution for render resolution", v=0)
    vfx_cam_db_ui_stuff["constraintCheck"] = cmds.checkBox(l=" Constraint Camera to Locator", v=0)
    vfx_cam_db_ui_stuff["groupCheck"] = cmds.checkBox(l=" Create empty parent group", v=0)
    cmds.setParent('..')
    cmds.separator(h=25, style="none")
    cmds.button(l="Create Camera", c='camFXDB.create_cam("' + opt_menu + '")')
    cmds.separator(h=10, style="none")
    cmds.button(l="Edit Selected Camera", c='camFXDB.edit_cam("' + opt_menu + '")')
    cmds.separator(h=40, style="none")
    col_h = cmds.columnLayout('vfxcamdbUIMCMini', q=1, h=1)
    cmds.window('vfxcamdbUI', e=1, h=col_h + 100)


def dig_replace(string_code):
    replacements = ['\xc2', '\xc3', '\x97', '\x93', '\xa0', '\xe2', '\x80', '\x99Cb', '\xe2', '\x80', '\x99Cr', '\xe2', '\x80', '\x99']
    for t in replacements:
        string_code = string_code.replace(t, "")
    return string_code


def _set_camera_display_options(camera_transform_name):
    camera_shapes = cmds.listRelatives(camera_transform_name, shapes=True, fullPath=True)
    if camera_shapes:
        camera_shape = camera_shapes[0]
        cmds.setAttr(camera_shape + ".displayFilmGate", 1)
        cmds.setAttr(camera_shape + ".displayGateMask", 1)
        short_shape = camera_shape.split("|")[-1]
        if cmds.attributeQuery("gateMaskColor", node=short_shape, exists=True):
            cmds.setAttr(camera_shape + ".gateMaskColor", 0, 0, 0, type='double3')

def _set_render_resolution():
    """Sets the render resolution based on the UI selection."""
    global vfx_cam_db_ui_stuff
    
    if cmds.checkBox(vfx_cam_db_ui_stuff["check"], q=1, v=True):
        resolution_scroll = vfx_cam_db_ui_stuff.get('imageResolutionScroll')
        if not resolution_scroll:
            cmds.warning("No resolution information found in UI.")
            return

        selected_resolutions = cmds.textScrollList(resolution_scroll, q=1, si=True)
        if not selected_resolutions:
            cmds.warning("No resolution selected in UI.")
            return
            
        resolution_txt = selected_resolutions[0]
        
        numbers = re.findall(r'\d+', resolution_txt)
        
        if len(numbers) >= 2:
            wd = int(numbers[0])
            ht = int(numbers[1])
            
            cmds.setAttr("defaultResolution.width", wd)
            cmds.setAttr("defaultResolution.height", ht)
            cmds.setAttr("defaultResolution.deviceAspectRatio", float(wd) / float(ht))
            cmds.evalDeferred('cmds.setAttr("defaultResolution.pixelAspect",1)')
        else:
            cmds.warning("Could not parse width and height from resolution string: " + resolution_txt)

def setup_camera_rig(camera_name, do_group, do_constraint):
    # Get transform node if shape is passed
    if cmds.nodeType(camera_name) == "camera":
        parents = cmds.listRelatives(camera_name, parent=True, fullPath=True)
        if parents:
            camera_name = parents[0]

    # Handle full paths for naming new objects
    short_name = camera_name.split('|')[-1]

    master_name = short_name + "_grp"
    target_name = short_name + "_loc"

    # Remove existing aim constraints first
    constraints = cmds.listConnections(camera_name, type="aimConstraint")
    if constraints:
        cmds.delete(constraints)

    # 1. Handle Grouping / Master Locator (must happen before constraint)
    if do_group:
        master_obj = None
        if not cmds.objExists(master_name):
            master_obj = cmds.spaceLocator(n=master_name)[0]
            cmds.matchTransform(master_obj, camera_name, pos=True, rot=True)
        else:
            master_obj = master_name

        # Parent Camera to Master
        camera_parents = cmds.listRelatives(camera_name, parent=True)
        if not camera_parents or camera_parents[0] != master_obj:
            cmds.parent(camera_name, master_obj)
            # Update camera_name to reflect new DAG path
            camera_name = cmds.listRelatives(master_obj, children=True, fullPath=True, type="transform")
            camera_name = [c for c in camera_name if c.split('|')[-1] == short_name][0]

    # 2. Handle Constraint / Target (after grouping so offset is correct)
    if do_constraint:
        target_obj = None
        if not cmds.objExists(target_name):
            target_obj = cmds.spaceLocator(n=target_name)[0]
        else:
            target_obj = target_name

        # Match target to camera first to get correct world position
        cmds.matchTransform(target_obj, camera_name, pos=True, rot=True)

        # Move target to COI along its local Z axis
        coi = cmds.getAttr(camera_name + ".centerOfInterest")
        cmds.move(0, 0, -coi, target_obj, r=True, os=True, wd=True)

        # Parent target to group if grouping is enabled
        if do_group:
            target_parents = cmds.listRelatives(target_obj, parent=True)
            if not target_parents or target_parents[0] != master_obj:
                cmds.parent(target_obj, master_obj)

        # Create Aim Constraint
        cmds.aimConstraint(target_obj, camera_name, maintainOffset=True, weight=1, aimVector=[0,0,-1], upVector=[0,1,0], worldUpType="scene")

def create_cam(_opt_menu):
    """
    Creates a camera based on selected options.
    :param _opt_menu: The option menu control (unused but required for callback signature).
    """
    global vfx_cam_db_ui_stuff
    
    sensor_scroll = vfx_cam_db_ui_stuff.get('sensorAreaScroll') or vfx_cam_db_ui_stuff.get('sensorDimensionsScroll')
    
    camera_name_input = cmds.textFieldGrp(vfx_cam_db_ui_stuff["camName"], q=1, tx=True)
    
    results = ""
    if cmds.objExists(camera_name_input):
        results = cmds.confirmDialog(message="\n'" + camera_name_input + "' exists in this scene.  Do you want to:\n", button=["Create New", "Edit Existing", "Cancel"])
        if results == "Cancel":
            return
    
    if not sensor_scroll:
        cmds.warning("No sensor information found.")
        return

    selected_sensors = cmds.textScrollList(sensor_scroll, q=1, si=1)
    if not selected_sensors:
        cmds.warning("No sensor dimensions selected.")
        return

    sensor_x, sensor_y = parse_dimensions(selected_sensors[0])
    sensor_x = sensor_x * 0.0393701
    sensor_y = sensor_y * 0.0393701
    
    camera_to_modify = camera_name_input

    if results == "Edit Existing":
        cmds.setAttr(camera_to_modify + ".horizontalFilmAperture", l=False)
        cmds.setAttr(camera_to_modify + ".verticalFilmAperture", l=False)
        cmds.setAttr(camera_to_modify + ".horizontalFilmAperture", sensor_x)
        cmds.setAttr(camera_to_modify + ".verticalFilmAperture", sensor_y)
    elif results == "Create New":
        cmds.delete(camera_to_modify)
        echo_objs = cmds.camera(name=camera_to_modify, verticalFilmAperture=sensor_y, horizontalFilmAperture=sensor_x)
        camera_to_modify = cmds.rename(echo_objs[0], camera_to_modify)
    else: # New camera
        echo_objs = cmds.camera(name=camera_to_modify, verticalFilmAperture=sensor_y, horizontalFilmAperture=sensor_x)
        camera_to_modify = cmds.rename(echo_objs[0], camera_to_modify)

    _set_render_resolution()
    _set_camera_display_options(camera_to_modify)
    
    do_group = cmds.checkBox(vfx_cam_db_ui_stuff["groupCheck"], q=1, v=True)
    do_constraint = cmds.checkBox(vfx_cam_db_ui_stuff["constraintCheck"], q=1, v=True)
    setup_camera_rig(camera_to_modify, do_group, do_constraint)


def edit_cam(_opt_menu):
    """
    Edits the selected camera based on selected options.
    :param _opt_menu: The option menu control (unused but required for callback signature).
    """
    global vfx_cam_db_ui_stuff
    
    sensor_scroll = vfx_cam_db_ui_stuff.get('sensorAreaScroll') or vfx_cam_db_ui_stuff.get('sensorDimensionsScroll')
    
    if not sensor_scroll:
        cmds.warning("No sensor information found.")
        return
            
    selected_sensors = cmds.textScrollList(sensor_scroll, q=1, si=1)
    if not selected_sensors:
        cmds.warning("No sensor dimensions selected.")
        return

    sensor_x, sensor_y = parse_dimensions(selected_sensors[0])
    sensor_x = sensor_x * 0.0393701
    sensor_y = sensor_y * 0.0393701
    
    _set_render_resolution()
    
    camera_names_list = cmds.ls(sl=True)
    for camera_transform in camera_names_list:
        shape_node = camera_transform
        if cmds.nodeType(shape_node) != "camera":
            children = cmds.listRelatives(shape_node, shapes=True, fullPath=True)
            if children and cmds.nodeType(children[0]) == "camera":
                shape_node = children[0]
        
        if cmds.nodeType(shape_node) == "camera":
            cmds.setAttr(shape_node + ".horizontalFilmAperture", l=False)
            cmds.setAttr(shape_node + ".verticalFilmAperture", l=False)
            cmds.setAttr(shape_node + ".horizontalFilmAperture", sensor_x)
            cmds.setAttr(shape_node + ".verticalFilmAperture", sensor_y)
            _set_camera_display_options(camera_transform)
            
            do_group = cmds.checkBox(vfx_cam_db_ui_stuff["groupCheck"], q=1, v=True)
            do_constraint = cmds.checkBox(vfx_cam_db_ui_stuff["constraintCheck"], q=1, v=True)
            setup_camera_rig(camera_transform, do_group, do_constraint)


def parse_dimensions(dim_string):
    if "mm" not in dim_string:
        return 0.0, 0.0
    parts = dim_string.split("mm")
    
    width_tokens = parts[0].split()
    if not width_tokens:
        return 0.0, 0.0
    width_str = width_tokens[-1]
    
    height_tokens = parts[1].split()
    if not height_tokens:
        return 0.0, 0.0
    height_str = height_tokens[-1].replace("x", "").replace("X", "")
    
    try:
        return float(width_str), float(height_str)
    except ValueError:
        return 0.0, 0.0
